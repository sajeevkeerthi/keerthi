﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using kudumbashree.Class;

namespace kudumbashree.home_login
{
    public partial class login : System.Web.UI.Page
    {
        Classlogin lobj = new Classlogin();
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataTable dtreg = new DataTable();
            DataTable dtuserreg = new DataTable();
            Classlogin lobj = new Classlogin();
            lobj.Username = Txtuser.Text;
            lobj.Password = Txtpass.Text;
            dtreg = lobj.ExecuteSelectQueries();
            dtuserreg = lobj.Loginmember();



            if (lobj.Username == "admin@gmail.com" && lobj.Password == "admin")
            {

                Response.Redirect("~/admin/AdminHome.aspx");
            }
            else if (dtreg.Rows.Count > 0)
            {
                Session["employee"] = Txtuser.Text;
                Session["name"] = Convert.ToString(dtreg.Rows[0]["name"]);
                Response.Redirect("~/employee/Employehome.aspx");
            }
            else if (dtuserreg.Rows.Count > 0)
            {
                Session["member"] = Txtuser.Text;
                Session["name"] = Convert.ToString(dtuserreg.Rows[0]["name"]);
                Response.Redirect("~/member/Memberhome.aspx");

            }

            else
            {
                Label2.Text = "INVALID USER NAME OR PASSWORD";
            }
        }
    }
}


  
    
