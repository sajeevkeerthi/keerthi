﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using kudumbashree.Class;


namespace kudumbashree.member
{
    public partial class loanapply : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


        }

        protected void btnaccept_Click(object sender, EventArgs e)
        {
            DataTable dtloan = new DataTable();
            Classloanaply loan = new Classloanaply();
            loan.Loantype = DropDownList1.SelectedItem.Text;
            loan.Loanname = Txtloanname.Text;
            loan.Requiredamount = Txtrequired.Text;
            loan.Pendingamount = Txtpending.Text;
            loan.Memberid = DropDownList2.SelectedItem.Text;
            loan.Applieddate = Txtaplied.Text;
            loan.Lastdateofapply = Txtlastdate.Text;
            loan.Status = Txtstatus.Text;
            loan.addloanaply();
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}