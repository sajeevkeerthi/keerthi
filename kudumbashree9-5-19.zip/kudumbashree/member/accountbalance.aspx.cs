﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using kudumbashree.Class;

namespace kudumbashree.member
{
    public partial class accountbalance : System.Web.UI.Page
    {
        kudumbashree.Class.accountbalence objac = new kudumbashree.Class.accountbalence();
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{
            //    objac.Mid = Convert.ToInt32(Session["mid"]);

            //    DataTable dt = new DataTable();
            //    dt = objac.ExecuteSelectQuery();
            //    if (dt.Rows.Count > 0)
            //    {
            //        GridView1.DataSource = dt;
            //        GridView1.DataBind();
            //    }

            }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            GridView1.Visible = false;
            Label1.Visible = true;
            TextBox1.Visible = true;
            //  sum=objac.balance();
            //TextBox1.Text = Convert.ToString(objac.balance());
           // TextBox1.Text =Convert.ToString(dt.Rows[0][0]);

        }

       
    }

    }   
            
          


                      
        

        
    
