﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using kudumbashree.Class;

namespace kudumbashree.admin
{
    public partial class memberview : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            DataTable dtReg = new DataTable();
            Classmemberreg Obj = new Classmemberreg();
            dtReg = Obj.ExecuteSelectQueries();
            if (dtReg.Rows.Count > 0)
            {
                GridView1.DataSource = dtReg;
                GridView1.DataBind();
            }
        }

        
    }
}