﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using kudumbashree.Class;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace kudumbashree.Class
{
    public class Classloanaply
    {
        private string loantype;
        private string loanname;
        private string requiredamount;
        private string pendingamount;
        private string memberid;
        private string applieddate;
        private string lastdateofapply;
        private string status;

        public string Loantype { get => loantype; set => loantype = value; }
        public string Loanname { get => loanname; set => loanname = value; }
        public string Requiredamount { get => requiredamount; set => requiredamount = value; }
        public string Pendingamount { get => pendingamount; set => pendingamount = value; }
        public string Applieddate { get => applieddate; set => applieddate = value; }
        public string Lastdateofapply { get => lastdateofapply; set => lastdateofapply = value; }
        public string Status { get => status; set => status = value; }
        public string Memberid { get => memberid; set => memberid = value; }

        string Connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(Connectionstring);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        public void addloanaply()
        {
            OpenConection();

            SqlCommand command = new SqlCommand("select max(loanid) from memberloan", con);
            int loanid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                loanid = (int)cMax;
                loanid++;
            }
            else
            {
                loanid = 300;
            }

            String qry = "insert into memberloan values ('" + loanid + "' ,@Loantype,@Loanname,@Requiredamount,@pendingamount,@Mid,@Applieddate,@Lastdateofapply,@status)";
            SqlCommand cmd = new SqlCommand(qry, con);

            cmd.Parameters.AddWithValue("@Loantype", Loantype);
            cmd.Parameters.AddWithValue("@Loanname", Loanname);
            cmd.Parameters.AddWithValue("@Requiredamount", Requiredamount);
            cmd.Parameters.AddWithValue("@pendingamount", pendingamount);
            cmd.Parameters.AddWithValue("@Mid", Memberid);
            cmd.Parameters.AddWithValue("@Applieddate", Applieddate);
            cmd.Parameters.AddWithValue("@Lastdateofapply", Lastdateofapply);
            cmd.Parameters.AddWithValue("@status", Status);
            cmd.ExecuteNonQuery();

        }
    }
}