﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using kudumbashree.Class;
using System.Data;
using System.Data.SqlClient;

namespace kudumbashree.Class
{
    public class Classunitreg
    {
        
        private string unitname;
        private string secratary;
        private string president;
        private string state;
        private string noofmember;
        private string bankname;
        private string accounnumber;

        
        public string Unitname { get => unitname; set => unitname = value; }
        public string Secratary { get => secratary; set => secratary = value; }
        public string President { get => president; set => president = value; }
        public string State { get => state; set => state = value; }
        public string Noofmember { get => noofmember; set => noofmember = value; }
        public string Bankname { get => bankname; set => bankname = value; }
        public string Accounnumber { get => accounnumber; set => accounnumber = value; }

        string Connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(Connectionstring);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        public void  insertunit ()
        {
            OpenConection();

            SqlCommand command = new SqlCommand("select max(unitid)from unitreg", con);
            int unitid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                unitid = (int)cMax;
                unitid++;
            }
            else
            {
                unitid = 600;
            }


            String qry = "insert into unitreg values ('" + unitid + "',@unitname,@secratary,@president,@state,@noofmember,@bankname,@accountnumber)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@unitname",unitname);
            cmd.Parameters.AddWithValue("@secratary", Secratary);
            cmd.Parameters.AddWithValue("@president", President);
            cmd.Parameters.AddWithValue("@state", State);
            cmd.Parameters.AddWithValue("@noofmember", noofmember);
            cmd.Parameters.AddWithValue("@bankname", Bankname);
            cmd.Parameters.AddWithValue("@accountnumber", Accounnumber);
            cmd.ExecuteNonQuery();


        }
             
    }
}