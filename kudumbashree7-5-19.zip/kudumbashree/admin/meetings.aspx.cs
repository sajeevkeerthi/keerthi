﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.IO;
using System.Web.UI.WebControls;
using System.Data;
using kudumbashree.Class;


namespace kudumbashree.admin
{
    public partial class meetings : System.Web.UI.Page
    {
        kudumbashree.Class.Classmeeting meet = new kudumbashree.Class.Classmeeting();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        
        
        protected void Button1_Click1(object sender, EventArgs e)
        {
            // DataTable dtmeeting = new DataTable();
            //Classmeeting meeting = new Classmeeting();
            meet.Dateofmeeting = Txtdate.Text;
            meet.Time = Txttime.Text;
            meet.Venue = Txtvenue.Text;
            meet.Noofmembers = Txtno.Text;
            meet.Writesome = Txtreport.Text;
            meet.Next_met_date = Txtd.Text;
            meet.Timeofmeeting = Txtti.Text;
            meet.Meetingvenue = Txtmve.Text;

            meet.save();

        }
    }
}