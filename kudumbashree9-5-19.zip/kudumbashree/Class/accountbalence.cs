﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using kudumbashree.Class;
using System.Data;
using System.Web.UI;
using System.IO;
using System.Data.SqlClient;


namespace kudumbashree.Class
{
    public class accountbalence
    {
        string Connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(Connectionstring);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        private  int mem_id;
        private int mid;
        private int sum;

        public int Mid { get => mid; set => mid = value; }
        public int Mem_id { get => mem_id; set => mem_id = value; }
        public int Sum { get => sum; set => sum = value; }



        //public DataTable ExecuteSelectQuery()
        //{
        //    OpenConection();
        //    DataTable dt = new DataTable();
        //    string qry = " select tdate,tweek,tamount from thrift where mid=@mid";
        //    SqlCommand cmd = new SqlCommand(qry, con);
        //    cmd.Parameters.AddWithValue("@mid", mid);
        //    cmd.ExecuteNonQuery();

        //    DataTable dtselect = new DataTable();
        //    SqlDataAdapter da = new SqlDataAdapter(cmd);
        //    da.Fill(dtselect);
        //    CloseConnection();
        //    return dtselect;


        //
        public void display()

        {
            DataTable dt = new DataTable();
            OpenConection();
            String qry = "select sum(tamount) from thrift where mid=@mid ";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@mid", Mid);
            cmd.Parameters.AddWithValue("@sum",Sum);
           // cmd.ExecuteNonQuery();
            Sum = cmd.ExecuteNonQuery();
            CloseConnection();
            
           
            // cmd.ExecuteNonQuery();
            
        }
    }
    
}