﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using kudumbashree.Class;
using System.Data;
using System.Data.SqlClient;
using System.IO;


namespace kudumbashree.Class
{
    public class Classlogin
    {
        private String username;
        private String password;

        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }


        string Connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(Connectionstring);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public DataTable ExecuteSelectQueries()
        {
            OpenConection();
            string qry = "select * from empreg  where username=@username  and password= @password ";

            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@password", password);

            cmd.ExecuteNonQuery();
            DataTable dtreg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtreg);
            CloseConnection();
            return dtreg;
        }
        public DataTable Loginmember()
        {

            OpenConection();
            string qry = "select * from memreg  where username=@username  and password= @password ";

            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@username", Username);
            cmd.Parameters.AddWithValue("@password", password);

            cmd.ExecuteNonQuery();
            DataTable dtuserreg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtuserreg);
            CloseConnection();
            return dtuserreg;
        }





        }
    }
       