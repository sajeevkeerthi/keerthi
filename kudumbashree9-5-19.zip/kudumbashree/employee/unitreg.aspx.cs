﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.IO;
using System.Web.UI.WebControls;
using System.Data;
using kudumbashree.Class;

namespace kudumbashree.employee
{
    public partial class unitreg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Btnadd_Click(object sender, EventArgs e)
        {
            DataTable dtemp = new DataTable();
            kudumbashree.Class.Classunitreg objunit = new kudumbashree.Class.Classunitreg();
            
            objunit.Unitname = Txtunitname.Text;
            objunit.Secratary = Txtsecratary.Text;
            objunit.President = Txtpresident.Text;
            objunit.State = Drpdwnstate.SelectedItem.Text;
            objunit.Noofmember = Drpnoofmember.SelectedItem.Text;
            objunit.Bankname = Drpbankname.SelectedItem.Text;
            objunit.Accounnumber = Txtaccno.Text;
            objunit.insertunit();
        }

      
       
    }
}