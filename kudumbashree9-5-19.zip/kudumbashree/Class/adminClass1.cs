﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace kudumbashree.Class
{
    public class adminclass1
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public SqlDataAdapter da = new SqlDataAdapter();
        public SqlDataReader dr;
        public DataTable dt = new DataTable();
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }
        public void ExecuteQueries(string Query_)
        {
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        public void ReadData(string sql)
        {
            OpenConection();
            SqlCommand cmd = new SqlCommand(sql, con);
            dr = cmd.ExecuteReader();
        }
        public void adapter(string sql)
        {
            OpenConection();
            SqlCommand cmd = new SqlCommand(sql, con);
            da.SelectCommand = cmd;
            da.Fill(dt);
        }
        private string username;
        private string password;
        private string status;

        public string Uname { get => username; set => username = value; }
        public string Pswd { get => password; set => password = value; }
        public string Status { get => status; set => status = value; }

        public DataTable VisitorLogin()
        {
            OpenConection();
            DataTable dtReg = new DataTable();

            string qry = "select username,password from empreg ";
            SqlCommand cmd = new SqlCommand(qry, con);

            cmd.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;
        }
        public DataTable RejectUser(string s)
        {
            OpenConection();
            DataTable dtRej = new DataTable();
            SqlCommand cmd = new SqlCommand("select username,password from empreg where empid=@empid", con);
            cmd.Parameters.AddWithValue("@empid", s);
            cmd.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtRej);
            CloseConnection();
            return dtRej;
        }
        public void FillGrid(string sql, GridView grdvw)
        {
            adapter(sql);
            if (dt.Rows.Count > 0)
            {
                //grdvw.DataSource = dt;
                grdvw.DataBind();
            }
        }
        public void RejectVisitor()
        {
            OpenConection();
            SqlCommand cmd = new SqlCommand("update empreg set status=@stat where username=@username and password=@password", con);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@stat", Status);
            cmd.Parameters.AddWithValue("@username", username);
            cmd.ExecuteNonQuery();
        }
    }
}