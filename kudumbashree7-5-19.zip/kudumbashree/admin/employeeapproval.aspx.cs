﻿using System;
using kudumbashree.Class;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;
using System.Data;
namespace kudumbashree.admin
{
    public partial class employeeapproval : System.Web.UI.Page
    {
        adminclass1 admin = new adminclass1();
        DataTable dtRej = new DataTable();

        protected void Page_Load(object sender, EventArgs e)
        {
              if (!IsPostBack)
            {
                DataTable dtReg = new DataTable();
               // admin.FillGrid("select * from empreg where status='Pending Approval/Rejection' ");
            }

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}