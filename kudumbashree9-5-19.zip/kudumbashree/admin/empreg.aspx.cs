﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using kudumbashree.Class;



namespace kudumbashree.admin
{
    public partial class empreg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Btnadd_Click(object sender, EventArgs e)
        {
            DataTable dtemp = new DataTable();
            kudumbashree.Class.Classemp objemp = new kudumbashree.Class.Classemp ();

            objemp.Name = Txtname.Text;
            objemp.Address = Txtaddress.Text;
            objemp.Phone = Txtph.Text;
            objemp.Dob = Txtdateob.Text;
            objemp.Occupation=Txtoccupation.Text;
            objemp.Usertype=DropDownList1.SelectedItem.Text;
            objemp.Unitname=Txtunitname.Text;
            objemp.Username = Txtuser.Text;
            objemp.Password = Txtpass.Text;
            objemp.Unitid = Txtunitid.Text;
            string filename = Path.GetFileName(photo.PostedFile.FileName);
            string ext = Path.GetExtension(filename);
            if (ext.ToLower() == ".jpg" || ext.ToLower() == ".bmp" || ext.ToLower() == ".png" || ext.ToLower() == ".jpeg")
            {
                string src = Server.MapPath("~/Photo") + "\\" + Txtname.Text + ".JPG";
                photo.PostedFile.SaveAs(src);
                string picpath = "~/photo/" + Txtname.Text + ".JPG";
                objemp.Photo= picpath;
            }


            objemp.insertemployee();


        }
    }
}