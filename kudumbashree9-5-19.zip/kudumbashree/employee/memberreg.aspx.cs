﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.IO;
using System.Web.UI.WebControls;
using System.Data;
using kudumbashree.Class;

namespace kudumbashree.employee
{
    public partial class memberreg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Btnadd_Click(object sender, EventArgs e)
        {
            DataTable dtmem = new DataTable();
            Classmemberreg memreg = new Classmemberreg();
            memreg.Name = Txtname.Text;
            memreg.Age = Txtage.Text;
            memreg.Dob = Txtdob.Text;
            memreg.Address = Txtaddress.Text;
            memreg.Mobile = Txtmobile.Text;
            memreg.Unitid = Txtunitid.Text;
            memreg.Education= DropDownList1.SelectedItem.Text;
            memreg.Occupation = Txtoccupation.Text;
            string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
            string ext = Path.GetExtension(filename);
            if (ext.ToLower() == ".jpg" || ext.ToLower() == ".bmp" || ext.ToLower() == ".png" || ext.ToLower() == ".jpeg")
            {
                string src = Server.MapPath("~/Photo") + "\\" + Txtname.Text + ".JPG";
                FileUpload1.PostedFile.SaveAs(src);
                string picpath = "~/photo/" + Txtname.Text + ".JPG";
                memreg.Photo = picpath;
            }
            memreg.Username = Txtuser.Text;
            memreg.Password = TxtPASS.Text;
            memreg.insertmember();
            Response.Redirect("~/homelogin/login.aspx");
        }
    }
}