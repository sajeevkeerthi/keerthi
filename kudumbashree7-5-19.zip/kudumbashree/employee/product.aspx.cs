﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using kudumbashree.Class;

namespace kudumbashree.employee
{
    public partial class product : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Btnsave_Click(object sender, EventArgs e)
        {
            DataTable dtemp = new DataTable();
            kudumbashree.Class.Classproduct objprd = new kudumbashree.Class.Classproduct();
            objprd.Productname = Txtprductname.Text;
            objprd.Price = Txtprice.Text;
            objprd.Quantity = Txtprice.Text;
            string filename = Path.GetFileName(FileUpload.PostedFile.FileName);
            string ext = Path.GetExtension(filename);
            if (ext.ToLower() == ".jpg" || ext.ToLower() == ".bmp" || ext.ToLower() == ".png" || ext.ToLower() == ".jpeg")
            {
                string src = Server.MapPath("~/Photo") + "\\" +Txtprductname.Text + ".JPG";
                FileUpload.PostedFile.SaveAs(src);
                string picpath = "~/photo/" + Txtprductname.Text + ".JPG";
                objprd.Photo = picpath;
            }
            objprd.addproduct();
            Response.Redirect("../employee/EmployeeHome.aspx");

        }
    }
}