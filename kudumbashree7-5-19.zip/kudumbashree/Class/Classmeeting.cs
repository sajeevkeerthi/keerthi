﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using kudumbashree.Class;
using System.Data;
using System.Data.SqlClient;

namespace kudumbashree.Class
{
    public class Classmeeting
    {
        private string dateofmeeting;
        private string time;
        private string venue;
        private string noofmembers;
        private string writesome;
       
        private string timeofmeeting;
        private string meetingvenue;
        private string next_met_date;

        public string Dateofmeeting { get => dateofmeeting; set => dateofmeeting = value; }
        public string Time { get => time; set => time = value; }
        public string Venue { get => venue; set => venue = value; }
       
        public string Timeofmeeting { get => timeofmeeting; set => timeofmeeting = value; }
        public string Meetingvenue { get => meetingvenue; set => meetingvenue = value; }
        public string Next_met_date { get => next_met_date; set => next_met_date = value; }
        public string Noofmembers { get => noofmembers; set => noofmembers = value; }
        public string Writesome { get => writesome; set => writesome = value; }

        string Connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(Connectionstring);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        public void save()
        {
            OpenConection();

            SqlCommand command = new SqlCommand("select max(meetingid)from meeting", con);
            int meetingid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                meetingid = (int)cMax;
                meetingid++;
            }
            else
            {
                meetingid = 800;
            }
    
            String qry = "insert into meeting values ('" + meetingid + "',@dateofmeeting,@venue,@time,@noofmembers,@writesome,@next_met_date,@timeofmeeting,@meetingvenue)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@dateofmeeting", Dateofmeeting); 
            cmd.Parameters.AddWithValue("@time", time);
            cmd.Parameters.AddWithValue("@venue", Venue);
            cmd.Parameters.AddWithValue("@noofmembers", Noofmembers);
            cmd.Parameters.AddWithValue("@writesome", Writesome);
            cmd.Parameters.AddWithValue("@next_met_date", Next_met_date);
            cmd.Parameters.AddWithValue("@timeofmeeting", Timeofmeeting);
            cmd.Parameters.AddWithValue("@meetingvenue",Meetingvenue);
            cmd.ExecuteNonQuery();
        }
    }
}