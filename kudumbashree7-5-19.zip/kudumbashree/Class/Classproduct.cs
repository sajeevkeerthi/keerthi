﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using kudumbashree.Class;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace kudumbashree.Class
{
    public class Classproduct
    
    {
        private string productname;
        private string price;
        private string quantity;
        private string photo;

        public string Productname { get => productname; set => productname = value; }
        public string Price { get => price; set => price = value; }
        public string Quantity { get => quantity; set => quantity = value; }
        public string Photo { get => photo; set => photo = value; }

        string Connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(Connectionstring);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        public void addproduct()
        {
            OpenConection();

            SqlCommand command = new SqlCommand("select max(pid) from product", con);
            int pid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                pid = (int)cMax;
                pid++;
            }
            else
            {
                pid = 500;
            }

            String qry = "insert into product values ('" + pid + "' ,@pname,@price,@qty,@photo)";
            SqlCommand cmd = new SqlCommand(qry, con);

            cmd.Parameters.AddWithValue("@pname",productname);
            cmd.Parameters.AddWithValue("@price", price);
            cmd.Parameters.AddWithValue("qty", quantity);
            cmd.Parameters.AddWithValue("@photo", photo);
            cmd.ExecuteNonQuery();



        }

    }
}