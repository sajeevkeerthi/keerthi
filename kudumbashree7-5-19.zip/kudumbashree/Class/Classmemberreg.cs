﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using kudumbashree.Class;
using System.Data;
using System.Data.SqlClient;


namespace kudumbashree.Class
{
    public class Classmemberreg
    {
        private string name;
        private string age;
        private string dob;
        private string address;
        private string mobile;
        private string unitid;
        private string education;
        private string occupation;
        private string photo;
        private string username;
        private string password;


        private string mid;

        public string Name { get => name; set => name = value; }
        public string Age { get => age; set => age = value; }
        public string Dob { get => dob; set => dob = value; }
        public string Address { get => address; set => address = value; }
        public string Mobile { get => mobile; set => mobile = value; }
        public string Unitid { get => unitid; set => unitid = value; }
        public string Education { get => education; set => education = value; }
        public string Occupation { get => occupation; set => occupation = value; }
        public string Photo { get => photo; set => photo = value; }
        public string Mid { get => mid; set => mid = value; }
        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }

        string Connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(Connectionstring);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        public void insertmember()
        {
        OpenConection();

            SqlCommand command = new SqlCommand("select max(mid)from memreg", con);
            int mid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                mid = (int)cMax;
                mid++;
            }
            else
            {
                mid = 400;
            }    

            //string a = "Pending";
            String qry = "insert into memreg values ('" + mid + "',@name,@age,@dob,@address,@mobile,@unitid,@education,@occupation,@photo,@username,@password)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@name", Name);
            cmd.Parameters.AddWithValue("@age", Age);
            cmd.Parameters.AddWithValue("@dob", Dob);
            cmd.Parameters.AddWithValue("@address",Address );
            cmd.Parameters.AddWithValue("@mobile", Mobile);
            cmd.Parameters.AddWithValue("@unitid", unitid);
            cmd.Parameters.AddWithValue("@education", Education);
            cmd.Parameters.AddWithValue("@occupation", Occupation);
            cmd.Parameters.AddWithValue("@photo", photo);
            cmd.Parameters.AddWithValue("@username", Username);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.ExecuteNonQuery();

        }


        //To View the member details in Grid

        public DataTable ExecuteSelectQueries()
        {
            OpenConection();
            DataTable dtReg = new DataTable();
            SqlCommand command = new SqlCommand("Select * from memreg ", con);

            SqlDataAdapter da = new SqlDataAdapter(command);// this will query your database and return the result to your datatable
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;
        }

       /* public void Updated()
        {
            string a = "Accepted";
            SqlCommand command = new SqlCommand("update memreg set status=@status there mid=@mid",con);
            command.Parameters.AddWithValue("@status", a);
            command.Parameters.AddWithValue("@mid", mid);
            command.ExecuteNonQuery();

        }*/

    }
}