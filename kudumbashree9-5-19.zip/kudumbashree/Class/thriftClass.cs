﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using kudumbashree.Class;
using System.Data;
using System.Web.UI;
using System.IO;
using System.Data.SqlClient;



namespace kudumbashree.Class
{
    public class thriftClass
    {
        private string unitid;
        private string thriftdate;
        private string thriftweek;
        private string memberid;
        private string thriftamount;
        private string totalamount;
        private string status;
        

        
        public string Thriftdate { get => thriftdate; set => thriftdate = value; }
        public string Thriftweek { get => thriftweek; set => thriftweek = value; }
        public string Memberid { get => memberid; set => memberid = value; }
        public string Thriftamount { get => thriftamount; set => thriftamount = value; }
        public string Status { get => status; set => status = value; }
        public string Unitid { get => unitid; set => unitid = value; }
        public string Totalamount { get => totalamount; set => totalamount = value; }

        string Connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(Connectionstring);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        public void save()
        {
            OpenConection();

            SqlCommand command = new SqlCommand("select max(thriftid)from thrift", con);
            int thriftid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                thriftid = (int)cMax;
                thriftid++;
            }
            else
            {
                thriftid = 100;
            }
            String qry = "insert into thrift values ('" + thriftid + "',@unitid,@thriftdate,@thriftweek,@mid,@thriftamount,@status)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@unitid", Unitid);
            cmd.Parameters.AddWithValue("@thriftdate", Thriftdate);
            cmd.Parameters.AddWithValue("@thriftweek", Thriftweek);
            cmd.Parameters.AddWithValue("@mid", Memberid);
            cmd.Parameters.AddWithValue("@thriftamount", Thriftamount);
            
            cmd.Parameters.AddWithValue("@status", Status);
            cmd.ExecuteNonQuery();
        }
        
            

        

    }
}