﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using kudumbashree.Class;


namespace kudumbashree.employee
{
    public partial class thriftt : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        
        }

        protected void Btnsave_Click(object sender, EventArgs e)
        {
            DataTable dttemp = new DataTable();
            kudumbashree.Class.thriftClass objthrift = new kudumbashree.Class.thriftClass();
            objthrift.Unitid = DropDownList3.SelectedItem.Text;
            objthrift.Thriftdate = Txtdate.Text;
            objthrift.Thriftweek = Txtweek.Text;
            objthrift.Memberid = DropDownList2.SelectedItem.Text;
            objthrift.Thriftamount = Txttotal.Text;
           
            objthrift.Status = DropDownList1.SelectedItem.Text;
           
            objthrift.save();




        }

       
    }
}