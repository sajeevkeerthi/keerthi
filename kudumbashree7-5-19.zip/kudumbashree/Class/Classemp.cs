﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using kudumbashree.Class;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace kudumbashree.Class
{
    public class Classemp
    {
        private string name;
        private string address;
        private string dob;
        private String phone;
        private string occupation;
        private string usertype;
        private string unitname;
           private string username;
        private string password;
        private string unitid;
        private string photo;




        public string Name { get => name; set => name = value; }
        public string Address { get => address; set => address = value; }
        public string Dob { get => dob; set => dob = value; }
        public string Phone { get => phone; set => phone = value; }
        public string Occupation { get => occupation; set => occupation = value; }
        public string Usertype { get => usertype; set => usertype = value; }
        public string Unitname { get => unitname; set => unitname = value; }
        public string Password { get => password; set => password = value; }
        public string Photo { get => photo; set => photo = value; }
        public string Unitid { get => unitid; set => unitid = value; }
        public string Username { get => username; set => username = value; }

        string Connectionstring = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(Connectionstring);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        public void insertemployee()
        {
            OpenConection();

            SqlCommand command = new SqlCommand("select max(empid) from empreg", con);
           int empid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                empid = (int)cMax;
                empid++;
            }
            else
            {
                empid = 200;
            }


            String qry = "insert into empreg values ('" + empid + "' ,@name,@address,@phone,@dob,@occupation,@usertype,@unitname,@username,@password,@unitid,@photo)";
            SqlCommand cmd = new SqlCommand(qry, con);
           
            cmd.Parameters.AddWithValue("@name",Name);
            cmd.Parameters.AddWithValue("@address",Address) ;
            cmd.Parameters.AddWithValue("@phone", Phone);
            cmd.Parameters.AddWithValue("@dob", dob);
            cmd.Parameters.AddWithValue("@occupation", Occupation);
            cmd.Parameters.AddWithValue("@usertype", Usertype);
            cmd.Parameters.AddWithValue("@unitname", Unitname);
            cmd.Parameters.AddWithValue("@username", Username);
            cmd.Parameters.AddWithValue("@password", Password);
            cmd.Parameters.AddWithValue("@unitid", Unitid);
            cmd.Parameters.AddWithValue("@photo", Photo);
            cmd.ExecuteNonQuery();

        }
    }
}